package Client.Services;

// basic enum type
public enum BillsType {
    School, Clothing, Restaurant, Other
};
