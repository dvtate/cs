package carddeck.service.classes;
public enum CardValue { 
	ACE, ONE, TWO, THREE, FOUR, FIVE,
	SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING 
};