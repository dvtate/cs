package carddeck.service.classes;
public enum CardSign {SPADE,CLUB,DIAMOND,HEART};